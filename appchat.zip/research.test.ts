import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("Research Router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should have research router", () => {
    const router = appRouter._def.record;
    expect(router).toHaveProperty("research");
  });

  it("should have AI router", () => {
    const router = appRouter._def.record;
    expect(router).toHaveProperty("ai");
  });

  it("should have conversation router", () => {
    const router = appRouter._def.record;
    expect(router).toHaveProperty("conversation");
  });

  it("should export AppRouter type", () => {
    expect(typeof appRouter).toBe("object");
    expect(appRouter).toHaveProperty("_def");
  });
});
