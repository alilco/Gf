import { describe, it, expect, vi, beforeEach } from "vitest";
import { AIBot } from "./bot";

// Mock fetch
global.fetch = vi.fn();

describe("AIBot", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should initialize with default values", () => {
    const bot = new AIBot();
    expect(bot.getToken()).toBeNull();
    expect(bot.getUser()).toBeNull();
    expect(bot.getBalance()).toBe(0);
    expect(bot.getChat()).toBeNull();
  });

  it("should generate random email on register", async () => {
    const bot = new AIBot();
    
    // Mock successful registration
    (global.fetch as any).mockResolvedValueOnce({
      status: 200,
      text: async () => JSON.stringify({
        success: true,
        user: {
          id: "test-user-123",
          tokenBalance: 100,
        },
      }),
      headers: new Map([
        ["Set-Cookie", "auth_token=test-token-123"],
      ]),
    });

    const result = await bot.register();
    
    expect(result).toBe(true);
    expect(bot.getUser()).toBe("test-user-123");
    expect(bot.getToken()).toBe("test-token-123");
    expect(bot.getBalance()).toBe(100);
  });

  it("should handle registration failure", async () => {
    const bot = new AIBot();
    
    // Mock failed registration
    (global.fetch as any).mockResolvedValueOnce({
      status: 400,
      text: async () => JSON.stringify({
        success: false,
      }),
      headers: new Map(),
    });

    const result = await bot.register();
    expect(result).toBe(false);
  });

  it("should return false if token is missing on init", async () => {
    const bot = new AIBot();
    const result = await bot.init();
    expect(result).toBe(false);
  });

  it("should return false if token is missing on create", async () => {
    const bot = new AIBot();
    const result = await bot.create();
    expect(result).toBe(false);
  });

  it("should return null if token is missing on send", async () => {
    const bot = new AIBot();
    const result = await bot.send("test message");
    expect(result).toBeNull();
  });
});
