import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { BookOpen, Smartphone, Tablet, Monitor } from "lucide-react";

export default function ResponsiveTest() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  if (!user) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="academic-header sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-accent" />
            <h1 className="text-xl font-bold">اختبار الاستجابة</h1>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/dashboard")}
          >
            العودة
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="mb-8">
          <h2 className="mb-2 text-3xl font-bold">اختبار الاستجابة والتوافقية</h2>
          <p className="text-muted">اختبر التطبيق على أحجام شاشات مختلفة</p>
        </div>

        {/* Device Sizes */}
        <div className="grid gap-6 md:grid-cols-3">
          {/* Mobile */}
          <div className="academic-section">
            <div className="mb-4 flex items-center gap-2">
              <Smartphone className="h-6 w-6 text-accent" />
              <h3 className="font-bold">الهاتف الذكي</h3>
            </div>
            <p className="mb-4 text-sm text-muted">
              عرض الشاشة: 320px - 480px
            </p>
            <div className="mb-4 rounded-lg border border-border bg-background p-4 text-center">
              <p className="text-xs text-muted">معاينة الهاتف</p>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              اختبر على الهاتف
            </Button>
          </div>

          {/* Tablet */}
          <div className="academic-section">
            <div className="mb-4 flex items-center gap-2">
              <Tablet className="h-6 w-6 text-accent" />
              <h3 className="font-bold">الجهاز اللوحي</h3>
            </div>
            <p className="mb-4 text-sm text-muted">
              عرض الشاشة: 768px - 1024px
            </p>
            <div className="mb-4 rounded-lg border border-border bg-background p-4 text-center">
              <p className="text-xs text-muted">معاينة الجهاز اللوحي</p>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              اختبر على الجهاز اللوحي
            </Button>
          </div>

          {/* Desktop */}
          <div className="academic-section">
            <div className="mb-4 flex items-center gap-2">
              <Monitor className="h-6 w-6 text-accent" />
              <h3 className="font-bold">سطح المكتب</h3>
            </div>
            <p className="mb-4 text-sm text-muted">
              عرض الشاشة: 1200px+
            </p>
            <div className="mb-4 rounded-lg border border-border bg-background p-4 text-center">
              <p className="text-xs text-muted">معاينة سطح المكتب</p>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              اختبر على سطح المكتب
            </Button>
          </div>
        </div>

        {/* Responsive Guidelines */}
        <div className="mt-12 academic-section">
          <h3 className="mb-4 font-bold">إرشادات الاستجابة</h3>
          <ul className="space-y-2 text-sm text-muted">
            <li>✓ الواجهة تتكيف تلقائياً مع أحجام الشاشات المختلفة</li>
            <li>✓ جميع الأزرار والحقول قابلة للنقر على الهواتف</li>
            <li>✓ النصوص قابلة للقراءة على جميع الأجهزة</li>
            <li>✓ الصور والرموز تتناسب مع حجم الشاشة</li>
            <li>✓ لا توجد شرائط تمرير أفقية غير مرغوبة</li>
          </ul>
        </div>

        {/* Browser Compatibility */}
        <div className="mt-6 academic-section">
          <h3 className="mb-4 font-bold">توافقية المتصفحات</h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="mb-2 font-medium">المتصفحات المدعومة:</p>
              <ul className="space-y-1 text-sm text-muted">
                <li>• Chrome 90+</li>
                <li>• Firefox 88+</li>
                <li>• Safari 14+</li>
                <li>• Edge 90+</li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-medium">الميزات المستخدمة:</p>
              <ul className="space-y-1 text-sm text-muted">
                <li>• CSS Grid & Flexbox</li>
                <li>• Fetch API</li>
                <li>• LocalStorage</li>
                <li>• ES6+ JavaScript</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
