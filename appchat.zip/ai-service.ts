import { AIBot } from "./ai-bot";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * AI Service for managing user sessions and AI interactions
 */

/**
 * Create a new AI session for a user
 */
export async function createAISession(userId: number): Promise<{ token: string; aiUserId: string; aiChatId: string } | null> {
  try {
    const bot = new AIBot();

    // Register with mr7.ai
    if (!(await bot.register())) {
      console.error("Failed to register with mr7.ai");
      return null;
    }

    // Initialize the session
    if (!(await bot.init())) {
      console.error("Failed to initialize AI session");
      return null;
    }

    // Create a chat
    if (!(await bot.create())) {
      console.error("Failed to create chat");
      return null;
    }

    const token = bot.getToken();
    const aiUserId = bot.getUser();
    const aiChatId = bot.getChat();

    if (!token || !aiUserId || !aiChatId) {
      console.error("Missing AI session data");
      return null;
    }

    // Save to database
    const db = await getDb();
    if (db) {
      await db
        .update(users)
        .set({
          aiToken: token,
          aiUserId: aiUserId,
          aiChatId: aiChatId,
          tokenBalance: bot.getBalance(),
        })
        .where(eq(users.id, userId));
    }

    return {
      token,
      aiUserId,
      aiChatId,
    };
  } catch (error) {
    console.error("Error creating AI session:", error);
    return null;
  }
}

/**
 * Send a message to the AI for a user
 */
export async function sendAIMessage(userId: number, message: string): Promise<string | null> {
  try {
    const db = await getDb();
    if (!db) {
      console.error("Database not available");
      return null;
    }

    // Get user's AI session
    const userRecord = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    if (!userRecord.length) {
      console.error("User not found");
      return null;
    }

    const user = userRecord[0];

    // If no AI session, create one
    if (!user.aiToken || !user.aiUserId || !user.aiChatId) {
      const session = await createAISession(userId);
      if (!session) {
        return null;
      }
    }

    // Create bot instance with existing session
    const bot = new AIBot();
    // Manually set the bot's properties from the database
    (bot as any).token = user.aiToken;
    (bot as any).user = user.aiUserId;
    (bot as any).chat = user.aiChatId;
    (bot as any).balance = user.tokenBalance || 0;

    // Send message
    const response = await bot.send(message);

    // Update token balance
    if (response) {
      await db
        .update(users)
        .set({
          tokenBalance: bot.getBalance(),
        })
        .where(eq(users.id, userId));
    }

    return response;
  } catch (error) {
    console.error("Error sending AI message:", error);
    return null;
  }
}

/**
 * Get user's AI session info
 */
export async function getAISessionInfo(userId: number) {
  try {
    const db = await getDb();
    if (!db) {
      return null;
    }

    const userRecord = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    if (!userRecord.length) {
      return null;
    }

    const user = userRecord[0];

    return {
      hasSession: !!user.aiToken && !!user.aiUserId && !!user.aiChatId,
      tokenBalance: user.tokenBalance || 0,
      aiUserId: user.aiUserId,
    };
  } catch (error) {
    console.error("Error getting AI session info:", error);
    return null;
  }
}
