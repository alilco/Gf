CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`researchId` int,
	`messages` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `researches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` text,
	`introduction` text,
	`chapters` json,
	`conclusion` text,
	`references` json,
	`status` enum('draft','completed') DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `researches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `aiToken` text;--> statement-breakpoint
ALTER TABLE `users` ADD `aiUserId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `aiChatId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `tokenBalance` int DEFAULT 0;