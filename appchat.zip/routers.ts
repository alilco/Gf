import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { AIBot } from "./bot";
import { z } from "zod";
import { getDb } from "./db";

// Store active bot sessions
const botSessions = new Map<string, AIBot>();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  ai: router({
    // Create a new session for the user
    createSession: publicProcedure.mutation(async () => {
      try {
        const bot = new AIBot();
        
        // Register new account
        const registered = await bot.register();
        if (!registered) {
          return {
            success: false,
            error: "Failed to register",
          };
        }

        // Wait a bit
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Initialize
        const initialized = await bot.init();
        if (!initialized) {
          return {
            success: false,
            error: "Failed to initialize",
          };
        }

        // Create chat
        const created = await bot.create();
        if (!created) {
          return {
            success: false,
            error: "Failed to create chat",
          };
        }

        // Store session
        const sessionId = bot.getUser() || `session-${Date.now()}`;
        botSessions.set(sessionId, bot);

        return {
          success: true,
          sessionId,
          email: bot.getEmail(),
          balance: bot.getBalance(),
        };
      } catch (error) {
        console.error("Create session error:", error);
        return {
          success: false,
          error: "Internal server error",
        };
      }
    }),

    // Send message to AI
    sendMessage: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        message: z.string(),
        model: z.string().optional().default("free"),
      }))
      .mutation(async ({ input }) => {
        try {
          const bot = botSessions.get(input.sessionId);
          if (!bot) {
            return {
              success: false,
              error: "Session not found",
              response: null,
            };
          }

          const response = await bot.send(input.message, input.model);
          
          return {
            success: !!response,
            response,
            balance: bot.getBalance(),
          };
        } catch (error) {
          console.error("Send message error:", error);
          return {
            success: false,
            error: "Failed to send message",
            response: null,
          };
        }
      }),

    // Get session info
    getSessionInfo: publicProcedure
      .input(z.object({
        sessionId: z.string(),
      }))
      .query(({ input }) => {
        const bot = botSessions.get(input.sessionId);
        if (!bot) {
          return {
            success: false,
            error: "Session not found",
          };
        }

        return {
          success: true,
          email: bot.getEmail(),
          balance: bot.getBalance(),
          hasChat: !!bot.getChat(),
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
