import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, Zap, MessageSquare, Brain } from "lucide-react";
import { toast } from "sonner";

export default function Home() {
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const createSessionMutation = trpc.ai.createSession.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success("تم إنشاء الحساب بنجاح!");
        // Navigate to chat with session ID
        navigate(`/chat/${data.sessionId}`);
      } else {
        toast.error(data.error || "حدث خطأ في إنشاء الحساب");
        setIsLoading(false);
      }
    },
    onError: () => {
      toast.error("حدث خطأ في الاتصال");
      setIsLoading(false);
    },
  });

  const handleCreateSession = async () => {
    setIsLoading(true);
    createSessionMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm">
        <div className="mx-auto max-w-4xl px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold text-gray-900">مساعدك الذكي</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-4xl font-bold text-gray-900 sm:text-5xl">
            مرحباً بك في مساعدك الذكي
          </h2>
          <p className="mb-8 text-lg text-gray-600">
            تطبيق ذكاء اصطناعي متقدم يساعدك في الإجابة على أي سؤال والقيام بأي مهمة
          </p>

          {/* Create Account Button */}
          <Button
            onClick={handleCreateSession}
            disabled={isLoading}
            className="mb-8 h-14 bg-gradient-to-r from-blue-600 to-blue-700 px-8 text-lg font-semibold text-white hover:from-blue-700 hover:to-blue-800 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                جاري إنشاء الحساب...
              </>
            ) : (
              <>
                <Zap className="mr-2 h-5 w-5" />
                ابدأ الآن - إنشاء حساب مجاني
              </>
            )}
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid gap-6 sm:grid-cols-3">
          {/* Feature 1 */}
          <div className="rounded-lg border border-blue-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold text-gray-900">دردشة ذكية</h3>
            <p className="text-sm text-gray-600">
              تحدث مع الذكاء الاصطناعي واحصل على إجابات فورية وموثوقة
            </p>
          </div>

          {/* Feature 2 */}
          <div className="rounded-lg border border-blue-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
              <Brain className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold text-gray-900">ذكاء متقدم</h3>
            <p className="text-sm text-gray-600">
              تقنيات الذكاء الاصطناعي الحديثة لفهم واستيعاب أسئلتك بشكل أفضل
            </p>
          </div>

          {/* Feature 3 */}
          <div className="rounded-lg border border-blue-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
              <Zap className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold text-gray-900">سريع وفعال</h3>
            <p className="text-sm text-gray-600">
              احصل على الإجابات بسرعة البرق مع دقة عالية وموثوقية كاملة
            </p>
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-12 rounded-lg bg-blue-50 p-6 sm:p-8">
          <h3 className="mb-4 text-xl font-semibold text-gray-900">كيف يعمل؟</h3>
          <ol className="space-y-3 text-gray-700">
            <li className="flex gap-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white flex-shrink-0">
                1
              </span>
              <span>اضغط على زر "ابدأ الآن" لإنشاء حساب مجاني</span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white flex-shrink-0">
                2
              </span>
              <span>سيتم إنشاء جلسة خاصة بك تلقائياً</span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white flex-shrink-0">
                3
              </span>
              <span>ابدأ المحادثة واسأل عن أي شيء تريده</span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white flex-shrink-0">
                4
              </span>
              <span>احصل على إجابات ذكية وموثوقة فوراً</span>
            </li>
          </ol>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-blue-100 bg-white/50 py-6 text-center text-sm text-gray-600">
        <p>© 2026 مساعدك الذكي. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
}
