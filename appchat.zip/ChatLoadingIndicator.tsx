import { Sparkles } from "lucide-react";

export function ChatLoadingIndicator() {
  return (
    <div className="flex items-center gap-2 text-muted">
      <div className="flex gap-1">
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: "0ms" }} />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: "150ms" }} />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: "300ms" }} />
      </div>
      <span className="text-sm">جاري الرد...</span>
    </div>
  );
}
