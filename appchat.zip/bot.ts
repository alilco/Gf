import crypto from 'crypto';
import { randomBytes } from 'crypto';

interface BotConfig {
  email?: string;
  token?: string;
  fingerprint?: string;
  fbp?: string;
  website?: string;
  user?: string;
  chat?: string;
  balance?: number;
  cache?: string;
}

export class AIBot {
  private email: string | null = null;
  private token: string | null = null;
  private fingerprint: string;
  private fbp: string;
  private website: string;
  private user: string | null = null;
  private chat: string | null = null;
  private balance: number = 0;
  private cache: string | null = null;

  constructor() {
    this.fingerprint = crypto.createHash('md5').update(randomBytes(16)).digest('hex');
    this.fbp = `fb.1.${Date.now()}.${Math.floor(Math.random() * (999999999999 - 100000000000 + 1)) + 100000000000}`;
    this.website = crypto.randomUUID();
  }

  private generateRandomEmail(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const length = Math.floor(Math.random() * 7) + 8; // 8-14 characters
    let email = '';
    for (let i = 0; i < length; i++) {
      email += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return email + '@gmail.com';
  }

  private generateRandomToken(length: number): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let token = '';
    for (let i = 0; i < length; i++) {
      token += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return token;
  }

  async register(): Promise<boolean> {
    this.email = this.generateRandomEmail();
    this.fingerprint = crypto.createHash('md5').update(randomBytes(16)).digest('hex');

    console.log('Email:', this.email);

    const headers = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/signup',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };

    const data = {
      email: this.email,
      password: '12323Aa4@@##',
      deviceFingerprint: this.fingerprint,
      recaptchaToken: this.generateRandomToken(Math.floor(Math.random() * 200) + 1600),
      referralCode: '5011BC5F',
    };

    try {
      const response = await fetch('https://mr7.ai/api/auth/register', {
        method: 'POST',
        headers,
        body: JSON.stringify(data),
      });

      const text = await response.text();
      console.log('Register response:', text);

      if (response.status !== 200 && response.status !== 201) {
        return false;
      }

      const result = JSON.parse(text);
      if (!result.success) {
        return false;
      }

      this.user = result.user.id;
      this.balance = result.user.tokenBalance || 0;

      // Extract token from Set-Cookie header
      const setCookie = response.headers.get('Set-Cookie');
      if (setCookie) {
        const match = setCookie.match(/auth_token=([^;]+)/);
        if (match) {
          this.token = match[1];
        }
      }

      return !!this.token;
    } catch (error) {
      console.error('Register error:', error);
      return false;
    }
  }

  async init(): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    const headers = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'referer': 'https://mr7.ai/chat',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
      'Cookie': `auth_token=${this.token}`,
    };

    const payload = JSON.stringify({
      "0": {"json": null, "meta": {"values": ["undefined"]}},
      "1": {"json": {"modelFilter": "all"}},
      "2": {"json": null, "meta": {"values": ["undefined"]}},
      "3": {"json": null, "meta": {"values": ["undefined"]}},
      "4": {"json": null, "meta": {"values": ["undefined"]}},
      "5": {"json": null, "meta": {"values": ["undefined"]}},
      "6": {"json": null, "meta": {"values": ["undefined"]}},
    });

    try {
      const url = new URL("https://mr7.ai/api/trpc/userReviews.shouldShowPopup,chat.list,subscription.status,subscription.canAccessChat,models.list,goldenMoment.status,agent.getSubscription?batch=1&input=" + encodeURIComponent(payload));
      
      const response = await fetch(url.toString(), {
        method: 'GET',
        headers,
      });

      if (response.status === 200) {
        const result = await response.json();
        if (Array.isArray(result) && result.length > 2) {
          const sub = result[2]?.result?.data?.json || {};
          if (sub.tokenBalance) {
            this.balance = sub.tokenBalance;
          }
        }
      }
    } catch (error) {
      console.error('Init error:', error);
    }

    // Initialize user reviews
    try {
      await fetch('https://mr7.ai/api/trpc/userReviews.init?batch=1', {
        method: 'POST',
        headers: {
          ...headers,
          'content-type': 'application/json',
        },
        body: JSON.stringify({"0": {"json": null, "meta": {"values": ["undefined"]}}}),
      });
    } catch (error) {
      console.error('Init reviews error:', error);
    }

    this.cache = crypto.randomUUID();

    return true;
  }

  async create(model: string = "free"): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    const headers = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/chat',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
      'Cookie': `auth_token=${this.token}`,
    };

    try {
      const response = await fetch('https://mr7.ai/api/trpc/chat.create?batch=1', {
        method: 'POST',
        headers,
        body: JSON.stringify({"0": {"json": {"modelType": model}}}),
      });

      if (response.status === 200) {
        const result = await response.json();
        this.chat = result[0]?.result?.data?.json?.id;
        console.log('Chat ID:', this.chat);
        return !!this.chat;
      }
      return false;
    } catch (error) {
      console.error('Create chat error:', error);
      return false;
    }
  }

  async send(content: string, model: string = "free"): Promise<string | null> {
    if (!this.token) {
      return null;
    }

    if (!this.chat) {
      if (!(await this.create(model))) {
        return null;
      }
    }

    const headers = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': `https://mr7.ai/chat/${this.chat}`,
      'cache-control': 'no-cache',
      'pragma': 'no-cache',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
      'Cookie': `auth_token=${this.token}`,
    };

    try {
      const response = await fetch('https://mr7.ai/api/chat/stream', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          chatId: this.chat,
          content,
          modelType: model,
          attachments: [],
          deepReasoning: false,
          webSearch: false,
        }),
      });

      if (response.status !== 200) {
        return null;
      }

      let answer = '';
      const reader = response.body?.getReader();
      if (!reader) return null;

      const decoder = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (!line || !line.startsWith('data:')) continue;
          const raw = line.slice(5).trim();
          if (!raw) continue;

          try {
            const event = JSON.parse(raw);
            if (event.type === 'chunk') {
              const part = event.content || '';
              if (part) {
                answer += part;
              }
            } else if (event.type === 'done') {
              const status = event.tokenStatus || {};
              if (status.balance) {
                this.balance = status.balance;
              }
            }
          } catch (e) {
            // Ignore JSON parse errors
          }
        }
      }

      console.log('\nAnswer:', answer);
      console.log('\nToken balance:', this.balance);

      return answer || null;
    } catch (error) {
      console.error('Send error:', error);
      return null;
    }
  }

  getToken(): string | null {
    return this.token;
  }

  getUser(): string | null {
    return this.user;
  }

  getBalance(): number {
    return this.balance;
  }

  getChat(): string | null {
    return this.chat;
  }

  getEmail(): string | null {
    return this.email;
  }
}
