import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { BookOpen, Save, Download, MessageSquare, Plus, Trash2, ArrowLeft, Printer } from "lucide-react";
import { ChatLoadingIndicator } from "@/components/ChatLoadingIndicator";
import { QuickSuggestions } from "@/components/QuickSuggestions";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface Chapter {
  id: string;
  title: string;
  content: string;
}

interface Reference {
  id: string;
  title: string;
  author: string;
  year: string;
}

export default function ResearchEditor({ params }: { params: { id: string } }) {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const researchId = parseInt(params.id);

  const [title, setTitle] = useState("");
  const [introduction, setIntroduction] = useState("");
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [conclusion, setConclusion] = useState("");
  const [references, setReferences] = useState<Reference[]>([]);
  const [activeTab, setActiveTab] = useState<"overview" | "chapters" | "references" | "chat">("overview");
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string }>>([]);

  // Fetch research
  const { data: research, isLoading } = trpc.research.get.useQuery({ id: researchId });

  // Update research mutation
  const updateMutation = trpc.research.update.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ البحث بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ في حفظ البحث");
    },
  });

  // AI message mutation
  const aiMutation = trpc.ai.sendMessage.useMutation({
    onSuccess: (data) => {
      if (data.success && data.response) {
        setChatHistory((prev) => [
          ...prev,
          { role: "user", content: chatMessage },
          { role: "assistant", content: data.response || "" },
        ]);
        setChatMessage("");
      }
    },
    onError: () => {
      toast.error("حدث خطأ في الحصول على رد من الذكاء الاصطناعي");
    },
  });

  // Load research data
  useEffect(() => {
    if (research) {
      setTitle(research.title || "");
      setIntroduction(research.introduction || "");
      setChapters(research.chapters || []);
      setConclusion(research.conclusion || "");
      setReferences(research.references || []);
    }
  }, [research]);

  if (!user) {
    navigate("/");
    return null;
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    updateMutation.mutate({
      id: researchId,
      title,
      introduction,
      chapters,
      conclusion,
      references,
    });
  };

  const handleAddChapter = () => {
    const newChapter: Chapter = {
      id: Date.now().toString(),
      title: "فصل جديد",
      content: "",
    };
    setChapters([...chapters, newChapter]);
  };

  const handleDeleteChapter = (id: string) => {
    setChapters(chapters.filter((ch) => ch.id !== id));
  };

  const handleUpdateChapter = (id: string, field: "title" | "content", value: string) => {
    setChapters(
      chapters.map((ch) =>
        ch.id === id ? { ...ch, [field]: value } : ch
      )
    );
  };

  const handleAddReference = () => {
    const newRef: Reference = {
      id: Date.now().toString(),
      title: "مرجع جديد",
      author: "",
      year: new Date().getFullYear().toString(),
    };
    setReferences([...references, newRef]);
  };

  const handleDeleteReference = (id: string) => {
    setReferences(references.filter((ref) => ref.id !== id));
  };

  const handleUpdateReference = (id: string, field: keyof Reference, value: string) => {
    setReferences(
      references.map((ref) =>
        ref.id === id ? { ...ref, [field]: value } : ref
      )
    );
  };

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    aiMutation.mutate({ message: chatMessage });
  };

  const handleExport = () => {
    const content = `${title}

المقدمة:
${introduction}

${chapters.map((ch) => `${ch.title}:\n${ch.content}`).join("\n\n")}

الخاتمة:
${conclusion}

المراجع:
${references.map((ref) => `${ref.title} - ${ref.author} (${ref.year})`).join("\n")}`;

    const element = document.createElement("a");
    element.setAttribute("href", `data:text/plain;charset=utf-8,${encodeURIComponent(content)}`);
    element.setAttribute("download", `${title}.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("تم تصدير البحث بنجاح");
  };

  const handlePrint = () => {
    const printWindow = window.open("", "", "height=600,width=800");
    if (printWindow) {
      const content = `<!DOCTYPE html>
<html dir="rtl">
<head>
<meta charset="UTF-8">
<title>${title}</title>
<style>
body { font-family: 'Arial', sans-serif; direction: rtl; line-height: 1.6; }
h1 { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; }
h2 { color: #333; margin-top: 20px; }
.section { margin: 20px 0; }
ul { list-style-position: inside; }
</style>
</head>
<body>
<h1>${title}</h1>
<div class="section"><h2>المقدمة</h2><p>${introduction.replace(/\n/g, "<br>")}</p></div>
${chapters.map((ch) => `<div class="section"><h2>${ch.title}</h2><p>${ch.content.replace(/\n/g, "<br>")}</p></div>`).join("")}
<div class="section"><h2>الخاتمة</h2><p>${conclusion.replace(/\n/g, "<br>")}</p></div>
<div class="section"><h2>المراجع</h2><ul>${references.map((ref) => `<li>${ref.title} - ${ref.author} (${ref.year})</li>`).join("")}</ul></div>
</body>
</html>`;
      printWindow.document.write(content);
      printWindow.document.close();
      setTimeout(() => printWindow.print(), 250);
    }
  };

  const handleQuickSuggestion = (suggestion: string) => {
    setChatMessage(suggestion);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="academic-header sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/dashboard")}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <BookOpen className="h-6 w-6 text-accent" />
            <h1 className="text-xl font-bold">محرر البحث</h1>
          </div>
          <div className="flex gap-2">
            <Button
              className="btn-primary"
              onClick={handleSave}
              disabled={updateMutation.isPending}
            >
              <Save className="mr-2 h-4 w-4" />
              حفظ
            </Button>
            <Button
              variant="outline"
              onClick={handleExport}
            >
              <Download className="mr-2 h-4 w-4" />
              تصدير
            </Button>
            <Button
              variant="outline"
              onClick={handlePrint}
            >
              <Printer className="mr-2 h-4 w-4" />
              طباعة
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Tabs */}
        <div className="mb-6 flex gap-2 border-b border-border overflow-x-auto">
          {(["overview", "chapters", "references", "chat"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-medium transition-colors whitespace-nowrap ${
                activeTab === tab
                  ? "border-b-2 border-accent text-accent"
                  : "text-muted hover:text-foreground"
              }`}
            >
              {tab === "overview" && "نظرة عامة"}
              {tab === "chapters" && "الفصول"}
              {tab === "references" && "المراجع"}
              {tab === "chat" && "الدردشة"}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="academic-section">
              <label className="mb-2 block font-medium">عنوان البحث</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="academic-input w-full"
                placeholder="أدخل عنوان البحث"
              />
            </div>

            <div className="academic-section">
              <label className="mb-2 block font-medium">المقدمة</label>
              <textarea
                value={introduction}
                onChange={(e) => setIntroduction(e.target.value)}
                className="academic-textarea w-full"
                rows={6}
                placeholder="أدخل المقدمة"
              />
            </div>

            <div className="academic-section">
              <label className="mb-2 block font-medium">الخاتمة</label>
              <textarea
                value={conclusion}
                onChange={(e) => setConclusion(e.target.value)}
                className="academic-textarea w-full"
                rows={6}
                placeholder="أدخل الخاتمة"
              />
            </div>
          </div>
        )}

        {/* Chapters Tab */}
        {activeTab === "chapters" && (
          <div className="space-y-6">
            {chapters.map((chapter) => (
              <div key={chapter.id} className="academic-section">
                <div className="mb-4 flex items-center justify-between gap-2">
                  <input
                    type="text"
                    value={chapter.title}
                    onChange={(e) => handleUpdateChapter(chapter.id, "title", e.target.value)}
                    className="academic-input flex-1"
                    placeholder="عنوان الفصل"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteChapter(chapter.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <textarea
                  value={chapter.content}
                  onChange={(e) => handleUpdateChapter(chapter.id, "content", e.target.value)}
                  className="academic-textarea w-full"
                  rows={8}
                  placeholder="محتوى الفصل"
                />
              </div>
            ))}

            <Button
              className="btn-primary"
              onClick={handleAddChapter}
            >
              <Plus className="mr-2 h-4 w-4" />
              إضافة فصل جديد
            </Button>
          </div>
        )}

        {/* References Tab */}
        {activeTab === "references" && (
          <div className="space-y-6">
            {references.map((ref) => (
              <div key={ref.id} className="academic-section">
                <div className="mb-4 flex items-center justify-between gap-2">
                  <input
                    type="text"
                    value={ref.title}
                    onChange={(e) => handleUpdateReference(ref.id, "title", e.target.value)}
                    className="academic-input flex-1"
                    placeholder="عنوان المرجع"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteReference(ref.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <input
                    type="text"
                    value={ref.author}
                    onChange={(e) => handleUpdateReference(ref.id, "author", e.target.value)}
                    className="academic-input"
                    placeholder="المؤلف"
                  />
                  <input
                    type="text"
                    value={ref.year}
                    onChange={(e) => handleUpdateReference(ref.id, "year", e.target.value)}
                    className="academic-input"
                    placeholder="السنة"
                  />
                </div>
              </div>
            ))}

            <Button
              className="btn-primary"
              onClick={handleAddReference}
            >
              <Plus className="mr-2 h-4 w-4" />
              إضافة مرجع جديد
            </Button>
          </div>
        )}

        {/* Chat Tab */}
        {activeTab === "chat" && (
          <div className="academic-section">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="md:col-span-2">
                <div className="mb-4 h-96 overflow-y-auto rounded-lg border border-border bg-background p-4">
                  {chatHistory.length === 0 && !aiMutation.isPending ? (
                    <div className="flex items-center justify-center h-full text-muted">
                      <p>ابدأ محادثة مع الذكاء الاصطناعي</p>
                    </div>
                  ) : aiMutation.isPending ? (
                    <ChatLoadingIndicator />
                  ) : (
                    <div className="space-y-4">
                      {chatHistory.map((msg, idx) => (
                        <div
                          key={idx}
                          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs rounded-lg px-4 py-2 ${
                              msg.role === "user"
                                ? "bg-accent text-accent-foreground"
                                : "bg-muted text-foreground"
                            }`}
                          >
                            {msg.content}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                    className="academic-input flex-1"
                    placeholder="اكتب سؤالك..."
                  />
                  <Button
                    className="btn-primary"
                    onClick={handleSendMessage}
                    disabled={aiMutation.isPending || !chatMessage.trim()}
                  >
                    <MessageSquare className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="academic-section">
                <QuickSuggestions onSuggestionClick={handleQuickSuggestion} />
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
