import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { renderHook } from "@testing-library/react";
import { useAutoSave } from "./useAutoSave";

describe("useAutoSave Hook", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.runOnlyPendingTimers();
    vi.useRealTimers();
  });

  it("should call onSave after delay", () => {
    const onSave = vi.fn();
    renderHook(() => useAutoSave({ onSave, delay: 1000 }));

    expect(onSave).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1000);
    expect(onSave).toHaveBeenCalledOnce();
  });

  it("should cancel previous timeout when dependencies change", () => {
    const onSave1 = vi.fn();
    const onSave2 = vi.fn();

    const { rerender } = renderHook(
      ({ onSave }) => useAutoSave({ onSave, delay: 1000 }),
      { initialProps: { onSave: onSave1 } }
    );

    vi.advanceTimersByTime(500);
    rerender({ onSave: onSave2 });

    vi.advanceTimersByTime(1000);
    expect(onSave1).not.toHaveBeenCalled();
    expect(onSave2).toHaveBeenCalledOnce();
  });

  it("should not call onSave when disabled", () => {
    const onSave = vi.fn();
    renderHook(() => useAutoSave({ onSave, delay: 1000, enabled: false }));

    vi.advanceTimersByTime(1000);
    expect(onSave).not.toHaveBeenCalled();
  });
});
