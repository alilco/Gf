import { useEffect, useRef } from "react";

interface UseAutoSaveOptions {
  onSave: () => void;
  delay?: number;
  enabled?: boolean;
}

/**
 * Hook for auto-saving data with debounce
 */
export function useAutoSave({ onSave, delay = 3000, enabled = true }: UseAutoSaveOptions) {
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!enabled) return;

    // Clear existing timeout
    if (timeoutRef.current !== null) {
      clearTimeout(timeoutRef.current);
    }

    // Set new timeout
    timeoutRef.current = setTimeout(onSave, delay);

    // Cleanup
    return () => {
      if (timeoutRef.current !== null) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [onSave, delay, enabled]);

  return {
    cancel: () => {
      if (timeoutRef.current !== null) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    },
  };
}
