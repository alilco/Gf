import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

interface QuickSuggestionsProps {
  onSuggestionClick: (suggestion: string) => void;
}

const QUICK_SUGGESTIONS = [
  "ساعدني في كتابة مقدمة قوية للبحث",
  "كيف أكتب فصل منظم وفعال؟",
  "ما هي أفضل طريقة لكتابة الخاتمة؟",
  "كيف أنسق المراجع بشكل صحيح؟",
];

export function QuickSuggestions({ onSuggestionClick }: QuickSuggestionsProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm font-medium text-muted">
        <Sparkles className="h-4 w-4" />
        <span>اقتراحات سريعة</span>
      </div>
      <div className="grid gap-2">
        {QUICK_SUGGESTIONS.map((suggestion) => (
          <Button
            key={suggestion}
            variant="outline"
            size="sm"
            className="justify-start text-left text-xs"
            onClick={() => onSuggestionClick(suggestion)}
          >
            {suggestion}
          </Button>
        ))}
      </div>
    </div>
  );
}
