import * as crypto from "crypto";

/**
 * AI Bot class for communicating with mr7.ai API
 * This class handles user registration, chat initialization, and message sending
 * All logic is preserved from the original Python implementation
 */
export class AIBot {
  private session: any;
  private email: string | null = null;
  private token: string | null = null;
  private fingerprint: string;
  private fbp: string;
  private website: string;
  private user: string | null = null;
  private chat: string | null = null;
  private balance: number = 0;
  private cache: string | null = null;

  constructor() {
    this.session = {}; // Placeholder for session management
    this.fingerprint = crypto.createHash("md5").update(crypto.randomBytes(16)).digest("hex");
    this.fbp = `fb.1.${Date.now()}.${Math.floor(Math.random() * (999999999999 - 100000000000 + 1)) + 100000000000}`;
    this.website = crypto.randomUUID();
  }

  /**
   * Register a new user with mr7.ai
   */
  async register(): Promise<boolean> {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    const emailLength = Math.floor(Math.random() * (14 - 8 + 1)) + 8;
    this.email = Array.from({ length: emailLength })
      .map(() => chars[Math.floor(Math.random() * chars.length)])
      .join("") + "@gmail.com";

    this.fingerprint = crypto.createHash("md5").update(crypto.randomBytes(16)).digest("hex");

    console.log("Generated email:", this.email);

    const headers = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      "content-type": "application/json",
      origin: "https://mr7.ai",
      referer: "https://mr7.ai/signup",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-device-fingerprint": this.fingerprint,
    };

    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    const recaptchaLength = Math.floor(Math.random() * (1800 - 1600 + 1)) + 1600;
    const recaptchaToken = Array.from({ length: recaptchaLength })
      .map(() => chars2[Math.floor(Math.random() * chars2.length)])
      .join("");

    const data = {
      email: this.email,
      password: "12323Aa4@@##",
      deviceFingerprint: this.fingerprint,
      recaptchaToken: recaptchaToken,
      referralCode: "5011BC5F",
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      const response = await fetch("https://mr7.ai/api/auth/register", {
        method: "POST",
        headers: headers,
        body: JSON.stringify(data),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const text = await response.text();
      console.log("Registration response:", text);

      if (!response.ok) {
        return false;
      }

      const result = JSON.parse(text);
      if (!result.success) {
        return false;
      }

      this.user = result.user.id;
      this.balance = result.user.tokenBalance || 0;

      // Extract token from response headers
      const setCookie = response.headers.get("set-cookie") || "";
      const match = setCookie.match(/auth_token=([^;]+)/);
      if (match) {
        this.token = match[1];
      }

      return !!this.token;
    } catch (error) {
      console.error("Registration error:", error);
      return false;
    }
  }

  /**
   * Initialize the bot session
   */
  async init(): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    const headers = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      referer: "https://mr7.ai/chat",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-device-fingerprint": this.fingerprint,
    };

    const payload = JSON.stringify({
      "0": { json: null, meta: { values: ["undefined"] } },
      "1": { json: { modelFilter: "all" } },
      "2": { json: null, meta: { values: ["undefined"] } },
      "3": { json: null, meta: { values: ["undefined"] } },
      "4": { json: null, meta: { values: ["undefined"] } },
      "5": { json: null, meta: { values: ["undefined"] } },
      "6": { json: null, meta: { values: ["undefined"] } },
    });

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      const response = await fetch(
        "https://mr7.ai/api/trpc/userReviews.shouldShowPopup," +
          "chat.list,subscription.status,subscription.canAccessChat," +
          "models.list,goldenMoment.status,agent.getSubscription" +
          "?batch=1&input=" +
          encodeURIComponent(payload),
        {
          method: "GET",
          headers: headers,
          signal: controller.signal,
        }
      );
      clearTimeout(timeoutId);

      if (response.ok) {
        const result = await response.json();
        if (Array.isArray(result) && result.length > 2) {
          const sub = result[2]?.result?.data?.json || {};
          if (sub) {
            this.balance = sub.tokenBalance || this.balance;
          }
        }
      }
    } catch (error) {
      console.error("Init error (non-critical):", error);
    }

    const headers2 = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      "content-type": "application/json",
      origin: "https://mr7.ai",
      referer: "https://mr7.ai/chat",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-device-fingerprint": this.fingerprint,
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      await fetch("https://mr7.ai/api/trpc/userReviews.init?batch=1", {
        method: "POST",
        headers: headers2,
        body: JSON.stringify({ "0": { json: null, meta: { values: ["undefined"] } } }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
    } catch (error) {
      console.error("Init review error (non-critical):", error);
    }

    this.cache = crypto.randomUUID();

    const headers3 = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      "content-type": "application/json",
      origin: "https://mr7.ai",
      referer: "https://mr7.ai/",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "cross-site",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-umami-cache": this.cache,
    };

    const data = {
      type: "event",
      payload: {
        website: this.website,
        screen: "1920x1080",
        language: "en",
        title: "mr7.ai - Advanced AI for Security Professionals",
        hostname: "mr7.ai",
        url: "https://mr7.ai/chat",
        referrer: "https://mr7.ai/login",
      },
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      const response = await fetch("https://manus-analytics.com/api/send", {
        method: "POST",
        headers: headers3,
        body: JSON.stringify(data),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        const result = await response.json();
        this.cache = result.cache || this.cache;
      }
    } catch (error) {
      console.error("Analytics error (non-critical):", error);
    }

    return true;
  }

  /**
   * Create a new chat session
   */
  async create(model: string = "free"): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    const headers = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      "content-type": "application/json",
      origin: "https://mr7.ai",
      referer: "https://mr7.ai/chat",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-device-fingerprint": this.fingerprint,
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      const response = await fetch("https://mr7.ai/api/trpc/chat.create?batch=1", {
        method: "POST",
        headers: headers,
        body: JSON.stringify({ "0": { json: { modelType: model } } }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        const result = await response.json();
        this.chat = result[0]?.result?.data?.json?.id;
        console.log("Chat created:", this.chat);
        return !!this.chat;
      }
      return false;
    } catch (error) {
      console.error("Create chat error:", error);
      return false;
    }
  }

  /**
   * Send a message to the AI
   */
  async send(content: string, model: string = "free"): Promise<string | null> {
    if (!this.token) {
      return null;
    }

    if (!this.chat) {
      if (!(await this.create(model))) {
        return null;
      }
    }

    const headers = {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9",
      "content-type": "application/json",
      origin: "https://mr7.ai",
      referer: `https://mr7.ai/chat/${this.chat}`,
      "cache-control": "no-cache",
      pragma: "no-cache",
      "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"Windows"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36",
      "x-device-fingerprint": this.fingerprint,
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 120000);
      const response = await fetch("https://mr7.ai/api/chat/stream", {
        method: "POST",
        headers: headers,
        body: JSON.stringify({
          chatId: this.chat,
          content: content,
          modelType: model,
          attachments: [],
          deepReasoning: false,
          webSearch: false,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (response.status !== 200) {
        return null;
      }

      let answer = "";
      const text = await response.text();
      const lines = text.split("\n");

      for (const line of lines) {
        if (!line || !line.startsWith("data:")) {
          continue;
        }

        const raw = line.substring(5).trim();
        if (!raw) {
          continue;
        }

        try {
          const event = JSON.parse(raw);

          if (event.type === "chunk") {
            const part = event.content || "";
            if (part) {
              answer += part;
            }
          } else if (event.type === "done") {
            const status = event.tokenStatus || {};
            if (status) {
              this.balance = status.balance || this.balance;
            }
          }
        } catch (e) {
          // Skip invalid JSON lines
        }
      }

      if (answer) {
        console.log("\n" + answer);
        console.log("\ntoken: " + this.balance);
      }

      return answer || null;
    } catch (error) {
      console.error("Send message error:", error);
      return null;
    }
  }

  // Getters
  getToken(): string | null {
    return this.token;
  }

  getUser(): string | null {
    return this.user;
  }

  getChat(): string | null {
    return this.chat;
  }

  getBalance(): number {
    return this.balance;
  }

  getEmail(): string | null {
    return this.email;
  }
}
