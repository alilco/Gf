import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { BookOpen, Plus, Trash2, Edit2, LogOut, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [showNewResearch, setShowNewResearch] = useState(false);
  const [newTitle, setNewTitle] = useState("");

  // Fetch researches
  const { data: researches, isLoading, refetch } = trpc.research.list.useQuery();

  // Create research mutation
  const createMutation = trpc.research.create.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success("تم إنشاء البحث بنجاح");
        setNewTitle("");
        setShowNewResearch(false);
        refetch();
        navigate(`/research/${data.id}`);
      }
    },
    onError: (error) => {
      toast.error("حدث خطأ في إنشاء البحث");
    },
  });

  // Delete research mutation
  const deleteMutation = trpc.research.delete.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success("تم حذف البحث بنجاح");
        refetch();
      }
    },
    onError: (error) => {
      toast.error("حدث خطأ في حذف البحث");
    },
  });

  const handleCreateResearch = () => {
    if (!newTitle.trim()) {
      toast.error("يرجى إدخال عنوان البحث");
      return;
    }
    createMutation.mutate({ title: newTitle });
  };

  const handleDeleteResearch = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا البحث؟")) {
      deleteMutation.mutate({ id });
    }
  };

  if (!user) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="academic-header sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-accent" />
            <h1 className="text-xl font-bold">باحثي | Bahethi</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted">{user.name}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                logout();
                navigate("/");
              }}
            >
              <LogOut className="mr-2 h-4 w-4" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="mb-2 text-3xl font-bold">مرحباً بك، {user.name}</h2>
          <p className="text-muted">إدارة بحوثك الأكاديمية وتطويرها مع مساعدة الذكاء الاصطناعي</p>
        </div>

        {/* Create New Research */}
        {!showNewResearch ? (
          <Button
            className="btn-primary mb-8"
            onClick={() => setShowNewResearch(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            بحث جديد
          </Button>
        ) : (
          <div className="academic-section mb-8">
            <h3 className="mb-4 font-bold">إنشاء بحث جديد</h3>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="أدخل عنوان البحث"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="academic-input flex-1"
              />
              <Button
                className="btn-primary"
                onClick={handleCreateResearch}
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "جاري..." : "إنشاء"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowNewResearch(false)}
              >
                إلغاء
              </Button>
            </div>
          </div>
        )}

        {/* Researches List */}
        <div>
          <h3 className="mb-4 text-xl font-bold">بحوثك</h3>

          {isLoading ? (
            <div className="text-center text-muted">جاري التحميل...</div>
          ) : !researches || researches.length === 0 ? (
            <div className="academic-section text-center">
              <BookOpen className="mx-auto mb-4 h-12 w-12 text-muted/50" />
              <p className="text-muted">لم تقم بإنشاء أي بحث حتى الآن</p>
              <Button
                className="btn-primary mt-4"
                onClick={() => setShowNewResearch(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                إنشاء بحث جديد
              </Button>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {researches.map((research) => (
                <div
                  key={research.id}
                  className="academic-section group relative"
                >
                  <div className="mb-4">
                    <h4 className="mb-2 font-bold line-clamp-2">{research.title}</h4>
                    <p className="text-xs text-muted">
                      {new Date(research.createdAt).toLocaleDateString("ar-SA")}
                    </p>
                  </div>

                  <div className="mb-4">
                    <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${
                      research.status === "completed"
                        ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-100"
                        : "bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-100"
                    }`}>
                      {research.status === "completed" ? "مكتمل" : "مسودة"}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="btn-primary flex-1"
                      onClick={() => navigate(`/research/${research.id}`)}
                    >
                      <Edit2 className="mr-2 h-4 w-4" />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteResearch(research.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Start Guide */}
        <div className="mt-12 academic-section">
          <div className="flex items-start gap-4">
            <Sparkles className="mt-1 h-6 w-6 flex-shrink-0 text-accent" />
            <div>
              <h3 className="mb-2 font-bold">نصائح للبدء</h3>
              <ul className="space-y-2 text-sm text-muted">
                <li>• ابدأ بإنشاء بحث جديد وأدخل عنوانك</li>
                <li>• استخدم محرر البحث لملء الأقسام المختلفة</li>
                <li>• تحدث مع الذكاء الاصطناعي للحصول على مساعدة</li>
                <li>• صدّر بحثك عند الانتهاء</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
