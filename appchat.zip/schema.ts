import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  /** mr7.ai API token for this user session */
  aiToken: text("aiToken"),
  /** mr7.ai user ID for this user session */
  aiUserId: varchar("aiUserId", { length: 255 }),
  /** mr7.ai chat ID for this user session */
  aiChatId: varchar("aiChatId", { length: 255 }),
  /** Token balance for AI API */
  tokenBalance: int("tokenBalance").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Academic research papers table
 */
export const researches = mysqlTable("researches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title"),
  introduction: text("introduction"),
  chapters: json("chapters").$type<Array<{ id: string; title: string; content: string }>>(),
  conclusion: text("conclusion"),
  references: json("references").$type<Array<{ id: string; title: string; author: string; year: string }>>(),
  status: mysqlEnum("status", ["draft", "completed"]).default("draft"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Research = typeof researches.$inferSelect;
export type InsertResearch = typeof researches.$inferInsert;

/**
 * AI chat conversations table
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  researchId: int("researchId"),
  messages: json("messages").$type<Array<{ role: string; content: string; timestamp: number }>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;