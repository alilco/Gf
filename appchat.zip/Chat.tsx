import { useState, useEffect, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, Send, ArrowLeft, Copy, Check } from "lucide-react";
import { toast } from "sonner";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function Chat() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/chat/:sessionId");
  const sessionId = params?.sessionId as string;

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch session info
  const sessionInfoQuery = trpc.ai.getSessionInfo.useQuery(
    { sessionId },
    { enabled: !!sessionId }
  );

  // Send message mutation
  const sendMessageMutation = trpc.ai.sendMessage.useMutation({
    onSuccess: (data) => {
      if (data.success && data.response) {
        const newMessage: Message = {
          id: `msg-${Date.now()}`,
          role: "assistant",
          content: data.response,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, newMessage]);
        setSessionInfo((prev: any) => ({
          ...prev,
          balance: data.balance,
        }));
      } else {
        toast.error(data.error || "حدث خطأ في الحصول على الرد");
      }
      setIsLoading(false);
    },
    onError: () => {
      toast.error("حدث خطأ في الاتصال");
      setIsLoading(false);
    },
  });

  useEffect(() => {
    if (sessionInfoQuery.data) {
      setSessionInfo(sessionInfoQuery.data);
    }
  }, [sessionInfoQuery.data]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!match) {
    return null;
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    sendMessageMutation.mutate({
      sessionId,
      message: input,
      model: "free",
    });
  };

  const handleCopyMessage = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    toast.success("تم نسخ الرسالة");
  };

  return (
    <div className="flex h-screen flex-col bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm">
        <div className="mx-auto max-w-4xl px-4 py-4 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate("/")}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="text-lg font-bold text-gray-900">مساعدك الذكي</h1>
                {sessionInfo && (
                  <p className="text-xs text-gray-500">
                    الرصيد: {sessionInfo.balance} رمز
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6">
          {messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-4 text-5xl">💬</div>
              <h2 className="mb-2 text-2xl font-bold text-gray-900">
                ابدأ محادثتك
              </h2>
              <p className="text-gray-600">
                اسأل عن أي شيء وسأساعدك بأفضل طريقة ممكنة
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`group max-w-xs rounded-lg px-4 py-3 sm:max-w-md md:max-w-lg ${
                      message.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-900 border border-blue-200 shadow-sm"
                    }`}
                  >
                    <p className="whitespace-pre-wrap break-words text-sm sm:text-base">
                      {message.content}
                    </p>
                    {message.role === "assistant" && (
                      <button
                        onClick={() => handleCopyMessage(message.content, message.id)}
                        className="mt-2 inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        {copiedId === message.id ? (
                          <>
                            <Check className="h-3 w-3" />
                            تم النسخ
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            نسخ
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="rounded-lg bg-white border border-blue-200 px-4 py-3 shadow-sm">
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                      <span className="text-sm text-gray-600">جاري الكتابة...</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-blue-100 bg-white/80 backdrop-blur-sm">
        <div className="mx-auto max-w-4xl px-4 py-4 sm:px-6">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اكتب سؤالك هنا..."
              disabled={isLoading}
              className="flex-1 rounded-lg border border-blue-200 bg-white px-4 py-3 text-sm placeholder-gray-500 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 disabled:opacity-50"
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="h-auto rounded-lg bg-blue-600 px-4 py-3 text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </form>
          <p className="mt-2 text-xs text-gray-500 text-center">
            هذا التطبيق يستخدم الذكاء الاصطناعي المتقدم لتقديم أفضل الإجابات
          </p>
        </div>
      </div>
    </div>
  );
}
