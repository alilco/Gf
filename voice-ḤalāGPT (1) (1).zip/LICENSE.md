# DarkPs NonCommercial License 1.0

**License identifier:** `DarkPs-NC-1.0`  
**Copyright:** © 2026 DarkPs / FanuonAI

This license is an independent license created by DarkPs / FanuonAI. It is inspired by the principles of attribution and non-commercial licensing, but it is **not** a Creative Commons license and is not endorsed, approved, or maintained by Creative Commons.

---

## 1. Definitions

### 1.1 Licensed Material

**"Licensed Material"** means the artificial-intelligence model, model weights, checkpoints, tokenizer files, configuration files, inference code, documentation, and other files expressly identified by the Licensor as being released under this License.

### 1.2 Adapted Material

**"Adapted Material"** means material based upon the Licensed Material that has been modified, fine-tuned, retrained, merged, quantized, pruned, distilled, converted, optimized, translated, rearranged, or otherwise adapted.

### 1.3 Share

**"Share"** means to provide material to another person or to the public by any means that requires permission under applicable copyright or similar rights, including copying, publishing, distributing, hosting, mirroring, or making the material available for download or access.

### 1.4 NonCommercial

**"NonCommercial"** means not primarily intended for or directed toward commercial advantage or monetary compensation.

The mere fact that a person, organization, platform, or website is commercial does not by itself make every use of the Licensed Material Commercial. The primary purpose and character of the particular use are relevant.

### 1.5 You

**"You"** means the person or legal entity exercising rights under this License.

### 1.6 Licensor

**"Licensor"** means DarkPs / FanuonAI and any party authorized by DarkPs / FanuonAI to distribute the Licensed Material under this License.

---

## 2. Scope of the License

Subject to the terms and conditions of this License, the Licensor grants You a worldwide, royalty-free, non-exclusive license to exercise the rights covered by this License in the Licensed Material for **NonCommercial purposes only**.

These rights include:

1. reproducing the Licensed Material;
2. sharing the Licensed Material;
3. creating Adapted Material;
4. reproducing Adapted Material; and
5. sharing Adapted Material.

These permissions include technical modifications reasonably necessary to exercise the rights granted by this License, including format conversion, quantization, pruning, optimization, and similar modifications.

No ownership of the Licensed Material is transferred to You.

---

## 3. Attribution

If You Share the Licensed Material or Adapted Material, You must provide appropriate attribution to the original Licensed Material and its Licensor, where such attribution information has been supplied.

The attribution must, to the extent reasonably practicable:

1. identify the original model or Licensed Material;
2. identify DarkPs / FanuonAI as the original Licensor where applicable;
3. provide the name of this License;
4. provide a link or other reasonable reference to the License;
5. provide a link or other reasonable reference to the original Licensed Material when available; and
6. indicate whether You modified the Licensed Material.

You may satisfy the attribution requirement in any reasonable manner based on the medium, means, and context in which You Share the material.

A recommended notice is:

> Based on **[ORIGINAL MODEL NAME]** by **DarkPs / FanuonAI**, licensed under the **DarkPs NonCommercial License 1.0**. Modified by **[NAME / ORGANIZATION]**.

You may not imply that DarkPs / FanuonAI endorses, sponsors, certifies, or officially supports You or Your Adapted Material unless You have separate written permission.

---

## 4. NonCommercial Restriction

You may not use the Licensed Material or Adapted Material for Commercial purposes.

Without limiting the definition of NonCommercial, the following are examples of Commercial use:

1. selling the Licensed Material or Adapted Material;
2. renting, leasing, or licensing access to the Licensed Material or Adapted Material for monetary compensation;
3. operating a paid API, paid hosted inference service, or subscription service in which the Licensed Material or Adapted Material is a material component;
4. using the Licensed Material or Adapted Material as a material component of a product or service primarily offered for commercial advantage or monetary compensation;
5. offering paid voice-generation, speech-generation, voice-cloning, or similar generation services using the Licensed Material or Adapted Material; or
6. otherwise using the Licensed Material or Adapted Material primarily for commercial advantage or monetary compensation.

The following are generally NonCommercial, subject to applicable law and all other terms of this License:

- personal use;
- private experimentation;
- educational use;
- non-commercial research;
- academic evaluation;
- non-commercial demonstrations; and
- non-commercial sharing.

Nothing in this section grants permission for a use that is independently prohibited by applicable law or third-party rights.

---

## 5. Adaptation and Derivative Models

You are expressly permitted to create Adapted Material.

You may, for example:

- change the model name;
- replace or modify branding;
- modify the architecture or configuration;
- fine-tune or retrain the model;
- merge it with another model;
- quantize, prune, distill, or optimize it;
- convert it to another format;
- modify or replace inference components; and
- create a new user interface for it.

You may Share Adapted Material for NonCommercial purposes, provided that You comply with this License.

An Adapted Material must not be represented as the unchanged original release.

---

## 6. Downstream Rights and No Additional Restrictions

Every recipient of the Licensed Material receives the same offer of rights under this License, subject to its terms.

You may not impose additional or different legal terms or effective technological measures on the Licensed Material that restrict recipients from exercising rights granted by this License.

You may license Your own original contributions under separate terms where those contributions are legally separable, provided that such terms do not remove or restrict the rights granted by this License in the Licensed Material itself.

---

## 7. Attribution in Adapted Material

When You Share Adapted Material, You may rename it and use Your own branding.

However, the attribution required by Section 3 must remain reasonably accessible.

An acceptable example is:

> **YourModel**  
> A modified and fine-tuned derivative of **OriginalModel** by **DarkPs / FanuonAI**.  
> Licensed under the **DarkPs NonCommercial License 1.0**.

---

## 8. Trademarks and Branding

This License does not grant trademark rights.

In particular, this License does not grant a right to use the **DarkPs** or **FanuonAI** names, logos, or other trademarks except as reasonably necessary to provide truthful attribution.

Changing the name and branding of Adapted Material is permitted.

You may not use DarkPs or FanuonAI branding in a manner that falsely suggests that Your Adapted Material is an official release, endorsed product, or certified version.

---

## 9. AI Output

Unless the accompanying documentation expressly states otherwise, the Licensor does not claim ownership of output generated by the Licensed Material solely because that output was generated with the model.

This License does not grant You any rights in third-party material that may appear in generated output.

You are responsible for determining whether Your use of generated output complies with applicable law and third-party rights.

---

## 10. Voices, Identity, and Third-Party Rights

Where the Licensed Material can synthesize or imitate voices or other identifiable characteristics, this License grants only those rights that the Licensor itself controls.

This License does not grant permission to use a third party's name, likeness, voice, identity, publicity rights, privacy rights, trademarks, performances, or other protected rights where separate permission is required.

You are solely responsible for obtaining any additional permissions required for Your particular use.

---

## 11. Third-Party Materials

The Licensed Material may incorporate, depend upon, reference, or have been trained using third-party software, datasets, recordings, voices, images, text, trademarks, or other materials.

Where a component is expressly identified as being subject to separate terms, those terms continue to apply.

This License grants only rights that the Licensor has authority to grant.

---

## 12. Exceptions and Limitations

Nothing in this License is intended to limit, restrict, or prevent any use that is permitted without permission under applicable law, including applicable exceptions and limitations to copyright or similar rights.

---

## 13. Moral Rights and Other Personal Rights

Where applicable, this License does not waive or license moral rights, privacy rights, publicity rights, personality rights, or similar personal rights to the extent they cannot legally be licensed.

To the extent permitted by law, the Licensor waives or agrees not to assert such rights held by the Licensor only as necessary to permit the uses expressly authorized by this License.

---

## 14. Patent Rights

No patent rights are granted by this License.

---

## 15. No Endorsement

Nothing in this License constitutes or implies any relationship of sponsorship, endorsement, certification, partnership, agency, or affiliation between You and DarkPs / FanuonAI.

---

## 16. Termination

This License applies automatically when You exercise any rights granted by it.

If You materially violate this License, Your rights under this License terminate automatically.

Your rights are reinstated automatically if You cure the violation within thirty (30) days after You become aware of the violation, or upon express reinstatement by the Licensor.

Termination does not affect rights acquired by recipients who received the Licensed Material from You in compliance with this License before termination.

---

## 17. Irrevocability

Subject to Section 16, the rights granted under this License are irrevocable for the applicable term of the rights covered by this License.

The Licensor may stop distributing a particular release, but that decision alone does not revoke the rights already granted under this License.

The Licensor may publish future versions or other materials under different terms.

---

## 18. Disclaimer of Warranties

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED MATERIAL IS PROVIDED **"AS IS"** AND **"AS AVAILABLE"**, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, WHETHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE.

THE LICENSOR DISCLAIMS ALL WARRANTIES, INCLUDING, WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, ACCURACY, RELIABILITY, AVAILABILITY, AND PERFORMANCE.

---

## 19. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSOR SHALL NOT BE LIABLE TO YOU OR ANY OTHER PERSON FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, OR OTHER DAMAGES ARISING OUT OF OR RELATED TO THIS LICENSE OR THE USE OF THE LICENSED MATERIAL, INCLUDING DAMAGES ARISING FROM GENERATED OUTPUT, LOSS OF PROFITS, LOSS OF DATA, OR BUSINESS INTERRUPTION.

---

## 20. Severability

If any provision of this License is found to be unenforceable or invalid, that provision shall be modified only to the minimum extent necessary to make it enforceable, and the remaining provisions shall remain in effect.

---

## 21. Interpretation

This License shall be interpreted to give the broadest effect possible to the permissions expressly granted while preserving the attribution and NonCommercial conditions.

Nothing in this License grants rights beyond those controlled by the Licensor or limits rights that cannot legally be limited.

---

## 22. Independent License

This License is an independent license created by DarkPs / FanuonAI.

It is not:

- Creative Commons Attribution-NonCommercial 4.0 International;
- an official Creative Commons license;
- an official Creative Commons adaptation; or
- an SPDX-approved license unless separately recognized by SPDX.

The terms **"Attribution"** and **"NonCommercial"** describe the principal conditions of this License and do not imply affiliation with Creative Commons.

---

## 23. Commercial Licensing

Commercial use is outside the scope of this License.

DarkPs / FanuonAI may grant separate written commercial permissions or licenses. Any such permission must be granted by the Licensor or an authorized representative.

**Commercial licensing:**  
[Request a License](https://t.me/sii_3) · [Alternative Contact](https://t.me/n1Dark)

---

## 24. Acceptance

By exercising rights granted by this License, You accept and agree to be bound by its terms.

If You do not agree to these terms, You may not exercise the rights granted by this License.

---

## 25. Recommended Repository Notice

> **License:** DarkPs NonCommercial License 1.0
> **Identifier:** `DarkPs-NC-1.0`  
> **Copyright:** © 2026 DarkPs / FanuonAI  
> **Commercial use:** Not permitted under this License. Separate written permission is required.

---

**End of DarkPs NonCommercial License 1.0**
